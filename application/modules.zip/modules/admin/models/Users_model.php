<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
 
 class Users_model extends CI_Model
    {
	public function __construct()
	{
	}
	public function get_admin($username=null,$password=null)
	{
         $query=$this->db->get_where('ci_admin_npr', array('admin_userName'=>$username,'admin_password'=>$password));
	return $query->row_array();
	}

public function get_user($username=nullm,$password=null){
         $query=$this->db->get_where('telecaller_tri', array('executive_email'=>$username,'executive_password'=>$password));
		return $query->row_array();
	}
	 
	public function get_email($admin_id)
	{
		$query = $this->db->query("SELECT  admin_userName  from admin_npr WHERE  admin_id=$admin_id" );
		return $query->row_array();
	}
	public function deleteCustomer($user_id)
	{
		//echo "DELETE from admin_npr WHERE admin_id='$user_admin_id'";
		$query = $this->db->query("DELETE from ci_customer_npr WHERE CustomerId=$user_id" );
		 // $this->db->delete("admin_npr",array(admin_id=>$user_admin_id));

		return true;
                 
		//return $query->row_array();
	}
	public function show($admin_id)
	{
		//echo "DELETE from admin_npr WHERE admin_id='$user_admin_id'";
		$query = $this->db->query("SELECT * from ci_customer_npr WHERE user_id=$admin_id" );
		return $query->row_array();
	}
	
	
	// customers Data

	public function InsertCustomer($saves){
		
	   if ($saves['CustomerId']!=""){
			$this->db->where('CustomerId', $saves['CustomerId']);
			$this->db->update('ci_customer_npr', $saves);
			
		
		}
		else{
			$this->db->insert('ci_customer_npr',$saves);
			$employee_id	= $this->db->insert_id();
			/*$this->db->where('EmpID', $employee_id);
			$this->db->update('employee_details', array('EmpCode'=>'LTS-'.$employee_id));
			if(!empty($user)){
			$user['EmpID']=$employee_id;
			$user['Username']='LTS-'.$employee_id;
			$user['Password']=md5('LTS-'.$employee_id);
			$this->db->insert('user_master', $user);
			$user_id	= $this->db->insert_id();
			
			$error = $this->db->error();
			if(!empty($error['message']))
			{
				return  array('succcess'=>false,'message'=>$error['message']);
			}
			*/
					
			return  array('succcess'=>true,'message'=>$error['message']);
			}
		
		return  array('succcess'=>true,'message'=>'User data successfully  entered');
	}
	
public function GetAllCustomers(){
	//$this->db->select( 'ph.*,uh.*,vh.CompanyName,vh.CompanyID,ug.GroupName,ug.GroupID,bh.BranchName,dh.Department');
	$this->db->select( 'ph.*');
	$this->db->from('ci_customer_npr ph');
	$this->db->order_by("ph.created_at", "ASC"); 
	$result = $this->db->get()->result();
	return $result;
    }
public function getCustomerById($id){
	$this->db->select( 'ph.*');
	$this->db->from('ci_customer_npr ph');

	$this->db->where ('ph.CustomerId',$id);
	$result = $this->db->get();
	return $result->row_array();
	
    }	
	
	public function update_pass($password,$admin_id)
	{
	         $data=array('admin_password'=>$password);
		     $this->db->where('admin_id',$admin_id);
		     $this->db->update('admin_npr',$data);
		     return 1;
	}
		
public function check_pass($params,$id){
 	$this->db->select( 'ph.*,');
	$this->db->from('admin_npr ph');
	$this->db->where('ph.admin_password', $params);
	$this->db->where('ph.admin_id',$id);
	$result = $this->db->get();
	return $result->row_array();

	}
	
/// CUSTOMERS

	public function getCustomerProducts($CompanyID){
	$this->db->select( 'wd.*,ed.EmployeeName,dp.Department');
	$this->db->from('work_details wd');
	$this->db->join('user_master um', 'um.UserID=wd.CreatedBy','INNER');
	$this->db->join('employee_details ed', 'ed.EmpID= um.EmpID','INNER');
	$this->db->join('userbranchaccess ub', 'um.UserID= ub.UserID','INNER');
	$this->db->join('department _master dp', 'dp.DepartmentID= ub.DepartmentID','INNER');
	$this->db->where('um.CompanyID',$CompanyID);
	if(!empty($params['BranchID'])){
		$this->db->where_in('ub.BranchID',$params['BranchID']);
		$this->db->where_in('ub.DepartmentID',$params['DepartmentID']);
	}
	if(!empty($params['startDate'])){
    		$this->db->where( "date(wd.CreatedDate) BETWEEN '".$params['startDate']."' AND '". $params['endDate']."'", NULL, FALSE );
	}else{
		$this->db->where( "date(wd.CreatedDate)",date('Y-m-d'));
	}
	if(!empty($params['Emp'])){
    $this->db->where('wd.CreatedBy',$params['Emp']);
  }
	//$this->db->where('dm.ParentID',$params['DepartmentID']);
	$this->db->order_by("wd.Workdate", "ASC");
    $result=$this->db->get()->result();
	return $result;
    }

    public function getCustomerTickets($customer_id){
	$this->db->select('ph.*,uh.*,tr.*');
	$this->db->from('ci_tickets_npr tr');
	$this->db->join('ci_tickets_assign_npr uh', 'tr.id=uh.ticket_id','LEFT');
	$this->db->join('ci_employee_npr ph', 'ph.empId=uh.employee_id','LEFT');
	$this->db->join('ci_product pr', 'pr.product_id=tr.product_code','LEFT');
	$this->db->join('ci_customer_npr cr',  'cr.CustomerId= tr.customer_id','INNER');
	$this->db->where('tr.customer_id',$customer_id);
	$this->db->order_by("tr.created_on", "DESC");
	$result = $this->db->get()->result();
	return $result;  }

public function GetAllWorks($CompanyID){
	$this->db->select( 'wd.*,ed.EmployeeName,dp.Department');
	$this->db->from('work_details wd');
	$this->db->join('user_master um', 'um.UserID=wd.CreatedBy','INNER');
	$this->db->join('employee_details ed', 'ed.EmpID= um.EmpID','INNER');
	$this->db->join('userbranchaccess ub', 'um.UserID= ub.UserID','INNER');
	$this->db->join('department _master dp', 'dp.DepartmentID= ub.DepartmentID','INNER');
	$this->db->where('um.CompanyID',$CompanyID);
	if(!empty($params['BranchID'])){
		$this->db->where_in('ub.BranchID',$params['BranchID']);
		$this->db->where_in('ub.DepartmentID',$params['DepartmentID']);
	}
	if(!empty($params['startDate'])){
    		$this->db->where( "date(wd.CreatedDate) BETWEEN '".$params['startDate']."' AND '". $params['endDate']."'", NULL, FALSE );
	}else{
		$this->db->where( "date(wd.CreatedDate)",date('Y-m-d'));
	}
	if(!empty($params['Emp'])){
    $this->db->where('wd.CreatedBy',$params['Emp']);
  }
	//$this->db->where('dm.ParentID',$params['DepartmentID']);
	$this->db->order_by("wd.Workdate", "ASC");
    $result=$this->db->get()->result();
	return $result;
    }

public function checkEmail($params){
 	$this->db->select( 'ph.*,');
	$this->db->from('ci_customer_npr ph');
	$this->db->like('ph.customer_email', $params);
	$result = $this->db->get();
	return $result->row_array();

	}

	
}
