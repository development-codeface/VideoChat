<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Profile extends MX_Controller {
	protected $data=array();
	private $UserId=null;
	function __construct() {
	parent::__construct();
	//error_reporting(E_ALL ^ (E_NOTICE | E_WARNING));
	$this->load->library(array( 'upload','form_validation'));
	
	if ($this->session->userdata('user_name') == ''){
					redirect('login');
	}
	$this->load->model('profile_model');
	$this->UserId=$this->session->userdata('user_id');
    }
	public function myProfile()
	{
		  
		$this->data['friendList']  = $this->users_model->GetFriendList($this->UserId) ;
		$this->data['profileViewer']  = $this->profile_model->GetProfileViewerList($this->UserId) ;
		$this->data['friendsRequest'] =    $this->users_model->GetFriendsRequest($this->UserId) ;
		$this->data['mydata'] =    $this->users_model->GetMyData($this->UserId) ;
		$this->data['feeds']   =    $this->profile_model->GetAllfeeds($this->UserId) ;
		$this->load->view("user/my-profile",$this->data);
		
	}
	
	
	public function profileView($friendId)
	{
		  
		$this->data['friendList']  = $this->users_model->GetFriendList($friendId) ;
		$this->data['profileViewer']  = $this->profile_model->GetProfileViewerList($friendId) ;
		$this->data['mydata'] =    $this->users_model->GetMyData($friendId) ;
		$this->data['feeds']   =    $this->profile_model->GetAllfeeds($friendId) ;
		$result= $this->profile_model->checkVisit(array('visitor_id'=>$this->UserId,'user_id'=>$friendId)) ;
		if(empty($result)){
		$s= $this->profile_model->InsertVisit(array('user_id'=>$friendId,'visitor_id'=>$this->UserId)) ;
		}
		$this->load->view("user/profile-view",$this->data);
		
	}
	
	

	public function settings()
	{
		  
		$this->data['friendsRequest'] =    $this->users_model->GetFriendsRequest($this->UserId) ;
		
		$this->load->view("user/profile-account-setting",$this->data);
		
	}
	public function messages()
	{
		  
		$this->data['feeds']   =    $this->profile_model->GetAllfeeds($this->UserId) ;
		$this->data['onlinef']    =    $this->users_model->GetOnlineFriends($this->UserId) ;
		
		$this->load->view("user/messages",$this->data);
		
	}
	public function messagesUser()
	{
		  
		$this->data['feeds']   =    $this->profile_model->GetAllfeeds($this->UserId) ;
		$this->data['onlinef']    =    $this->users_model->GetOnlineFriends($this->UserId) ;
		
		$this->load->view("user/messages_user",$this->data);
		
	}
	public function notifications()
	{
		  
		$this->data['feeds']   =    $this->profile_model->GetAllfeeds($this->UserId) ;
		$this->data['onlinef']    =    $this->users_model->GetOnlineFriends($this->UserId) ;
		
		$this->load->view("user/notification",$this->data);
		
	}
	
	public function profileSearch()
	{
		  
		$this->data['feeds']    =    $this->profile_model->GetAllfeeds($this->UserId) ;
		$this->data['onlinef']    =    $this->users_model->GetOnlineFriends($this->UserId) ;
		
		$this->load->view("user/public-profile",$this->data);
		
	}
	public function friends()
	{
		  
		$this->data['friendList']  = $this->users_model->GetFriendList($this->UserId) ;
		$this->data['friendOnline'] = $this->users_model->GetOnlineFriends($this->UserId) ;
		$this->data['friendsRequest'] =    $this->users_model->GetFriendsRequest($this->UserId) ;
		
		$this->load->view("user/profiles",$this->data);
		
	}
	
	
	
	
}