<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Auth extends  MX_Controller {
	
	function __construct() {
	parent::__construct();
	//error_reporting(E_ALL ^ (E_NOTICE | E_WARNING));
	$this->load->library(array('session', 'upload','form_validation'));
	$this->load->helper(array('url', 'html', 'form'));
	
    }
	
	public function index(){
		$data['tab'] = 'index';
		if($this->input->post("submit"))
		{
			$this->form_validation->set_rules('username','User name','required');
			$this->form_validation->set_rules('password','Password','required');
			if($this->form_validation->run() == TRUE)
			{
			$uname = stripslashes($this->input->post("username"));
			$paswrd = stripslashes(md5($this->input->post("password")));
			$result = $this->users_model->getUserLogin($uname, $paswrd);
			if(!$result || $result == FALSE)
			{
				$this->session->set_flashdata('err_msg','Incorrect Username/Password');
				redirect('/',"refresh");
			} else {
				$users_id = $result['user_id'];
				$users_name = $result['user_name'];
				$session_array = array('user_id'=>$users_id,'user_name'=>$users_name);
				$this->session->set_userdata($session_array);
				$param['user_id']=$users_id;
				$unameTest=$this->users_model->UpdateOnline($users_id);
				$result = $this->users_model->InsertOnline($param);
				redirect('frondend/user/profile',"refresh");
				
		}
		}}
		$this->load->view('auth/sign-in', $data);
	}
	
	
	
	public function register(){
		$data['tab'] = 'register';
		
		if(isset($_POST['register'])){
			$this->form_validation->set_rules('name','Name','required');
			$this->form_validation->set_rules('email','Email','required');
			$this->form_validation->set_rules('phone_no','Phone Number','required');
			$this->form_validation->set_rules('u_name','User name','required');
			$this->form_validation->set_rules('u_pass','Password','required');
			$this->form_validation->set_rules('cc','agreement','required');
			if($this->form_validation->run() == TRUE){
				$insertData=array('full_name'=>$this->input->post("name"),'email'=>$this->input->post("email"),'mobile'=>$this->input->post("phone_no"),'user_name'=>$this->input->post("u_name"),'password'=>md5($this->input->post("u_pass")));
				$result_data = $this->users_model->InsertUser($insertData);
				if($result_data['success'])
				{
					$this->session->set_flashdata("success",'Successfully registered..Please login to continue !!');
					redirect('/', "refresh");
				}
			}
		}
		$this->load->view('auth/sign-in', $data);
	}

	public function checkEmail(){
		$params =$this->input->post('email');
		$emailTest=$this->users_model->checkEmail($params);
		if(!empty($emailTest)){echo json_encode(array('status'=>1));}else{echo json_encode(array('status'=>0));}
	}

	public function checkUsername(){
		$params =$this->input->post('uname');
		$unameTest=$this->users_model->checkUserName($params);
		if(!empty($unameTest)){echo json_encode(array('status'=>1));}else{echo json_encode(array('status'=>0));}
	}


public function logout() {
	$user_id=$this->session->userdata('user_id');
	
	$unameTest=$this->users_model->UpdateOnline($user_id);
	$array_items = array('user_name' => '', 'user_id' => '');
	$this->session->unset_userdata($array_items);
	$this->session->sess_destroy();
	$page_content['error'] = "Logged out successfully";
	$page_content['title'] = 'Login';
	redirect(base_url());
}

}