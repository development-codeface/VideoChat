<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
 
 class Profile_model extends CI_Model
    {
	public function __construct()
	{
	}
	

	public function GetAllfeeds($userId){
	$this->db->select( 'DISTINCT(us.user_id),up.profile_pic,up.nick_name,us.full_name,uf.feeds,uf.no_likes');
	$this->db->from('users us');
	$this->db->join('friends um', 'um.friend_id=us.user_id','INNER');
	$this->db->join('user_profile up', 'up.user_id=us.user_id','INNER');
	$this->db->join('user_feed uf', 'uf.user_id= us.user_id','INNER');
	
	$this->db->where('um.user_id',$userId);
	$this->db->where('uf.status',1);
	$this->db->group_by('us.user_id'); 

	//$this->db->where('dm.ParentID',$params['DepartmentID']);
	$this->db->order_by("uf.created_at", "ASC");
    $result=$this->db->get()->result();
	return $result;
    }

    public function GetProfileViewerList($userId){
	$this->db->select( 'us.user_id,up.profile_pic,up.nick_name,us.full_name');
	$this->db->from('users us');
	$this->db->join('profile_visit um', 'um.visitor_id=us.user_id','INNER');
	$this->db->join('user_profile up', 'up.user_id=us.user_id','INNER');
	$this->db->where('um.user_id',$userId);
	$this->db->order_by("us.user_id", "ASC");
    $result=$this->db->get()->result();
	return $result;
    }
	public function checkVisit($params)
	{
		$this->db->select( 'ph.*,');
		$this->db->from('profile_visit ph');
		$this->db->where('ph.visitor_id', $params['visitor_id']);
		$this->db->where('ph.user_id', $params['user_id']);
		$result = $this->db->get();
		return $result->row_array();
		
	}
	public function InsertVisit($params)
	{
		$this->db->insert('profile_visit',$params);
		$user_id	= $this->db->insert_id();
		$error = $this->db->error();
		$query = $this->db->query("DELETE FROM  profile_visit where user_id=0" );
		return $user_id;
		
	}
}
