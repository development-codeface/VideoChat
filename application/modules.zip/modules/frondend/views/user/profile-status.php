<?php
include 'header.php' ;?>	

	<section class="pubsec">
		<div class="container">
		<div class="row">
		
		<div class="col-md-8">
		<?php  if(!empty($feeds)){
		foreach($feeds as $fd){?>
		<div class="post-bar">
													<div class="post_topbar">
													<div class="usy-dt">
														<img src="<?php echo base_url(); ?>assets/images/m-img2.png" alt="">
														<div class="usy-name">
															<h3><?php echo $fd->nick_name;?></h3>
															<span>
1 hr</span> &nbsp;<span><i class="fa fa-flag" aria-hidden="true"></i> India</span>
														</div>
													</div>
													
												</div>
												
												<div class="job_descp">
													<h3>Amazing Tomato Carving Arts</h3>
													
													
													<p><?php echo $fd->feeds;?>..... </p>
										
												</div>
				
												<div class="job-status-bar">
													<ul class="like-com">
														<li>
															<a href="#"><i class="la la-heart"></i> Like</a>
															<img src="<?php echo base_url(); ?>assets/images/liked-img.png" alt="">
															<!-- <span>25</span> -->
														</li> 
														
													</ul>
												
												</div>
		</div><?php } }?>
											
										
		</div>
		<div class="col-md-4">
		<div class="suggestions full-width">
										<div class="sd-title">
											<h3>Online Friends</h3>
											
										</div><!--sd-title end-->
										<div class="suggestions-list">
										<?php if(!empty($friendOnline)){
											$i=1;
											foreach($friendOnline as $frq){?>
											<div class="suggestion-usd">
										
												<img src="<?php echo base_url(); ?>assets/images/resources/s1.png" alt="">
													<span class="fa fa-circle msg-topaa"></span>
												<div class="sgt-text">
													<h4><?php echo $frq->full_name;?></h4>
													
												</div>
												<span><i class="fa fa-video-camera" aria-hidden="true"></i></span>
											</div>
										<?php }}?>
											
											
											
											
										
										</div><!--suggestions-list end-->
									</div>
		</div>
		</div>
		</div>
		</section>

<?php
include 'footer.php';?>

	