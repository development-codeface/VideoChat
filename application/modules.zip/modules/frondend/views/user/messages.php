<?php
include 'header.php';?>
<section>
<div class="container con49">
<div class="row">
<div class="col-md-2"></div>
<div class="col-md-8">
<div class="bgvid">
<a class="btn icon-btn btn-warning" href="#">
<span class="glyphicon btn-glyphicon glyphicon-minus fa fa-video-camera img-circle text-warning"></span>
 Video Chat
</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<a class="btn icon-btn btn-warning" href="messages_user.html">
<span class="glyphicon btn-glyphicon glyphicon-minus fa fa-comments-o img-circle text-warning"></span>
Messages
</a>
<div>

<div id="London" class="tabcontent tabb" style="display:block;">

 <div class="row">

 <div class="col-md-12">
   <img src="images/images.jpg" alt="Los Angeles" class="widt100">
 </div>

 </div>

</div>

<div id="Paris" class="tabcontent">
 <div class="row">
 <div class="sd-title">
											<h3>Messages</h3>
											
										</div>
										<br><br><br><br><br>
 <div class="col-md-12">
   <img src="images/google_hangouts_ipad_best_apps_screens.png" alt="Los Angeles" class="widt100">
 </div>

 </div>

</div>

<div id="Tokyo" class="tabcontent">
  <h3>Tokyo</h3>
  <p>Tokyo is the capital of Japan.</p>
</div>
</div>
</div>
</div>
</section>




	<?php
include 'footer.php';?>