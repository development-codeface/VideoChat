<?php
include 'header.php';?>
<section class="banner-img1 text-white py-55">
    <div class="container">
      
        <div class="row">
            <div class="col-md-12">
                <div class="row">
                    <div class="col-md-12">
                     
                        <div class="tab-content" id="nav-tabContent">
                          <div class="tab-pane tabbanc fade show active" id="nav-home" role="tabpanel" aria-labelledby="nav-home-tab">
                              <div class="card bg-primary card-body text-white sepro">
                       <div class="row pb-3">
                           <div class="col-md-12">
                               <h4>Search Public Profile  </h4>
                           </div>
                       </div>
                       
                       <div class="row">
           <form method="post" action="<?php echo base_url(); ?>index.php/frondend/User/searchFriends" name="logform" class="form-inline inlbg"style="width: 100%;">
				
		    <div class="col-lg-4">
			<div class="form-group frmlook">
			  <label for="focusedInput">I'm looking for:</label>
			  <div class="custom-select">
				<select name="looking">
				<option value="3">friends</option>
				<option value="2">A guy</option>
				<option value="1">A girl</option>
			</select>
</div>
</div>
  
    </div>
	    <div class="col-lg-4">
    <div class="form-group frmlook">
      <label for="focusedInput">Aged:</label>
	  		  <div class="custom-select">
  <select name="age">
               <option>18-20 years old</option>
    <option>20-22 years old</option>
    <option>22-25 years old</option>
  </select>
</div>
     
    </div>
    </div>
	    <div class="col-lg-2">
    <div class="form-group frmlook">
      <label for="focusedInput">From:</label>
	   		  <div class="custom-select">
  <select name="country">
             <option value="India">India</option>
			<option value="pakistan">Pakistan</option>
			<option value="England">England</option>
			<option value="China">China</option>
			<option value="UAE">UAE</option>
			<option value="United Sates">United Sates</option>
  </select>
</div>
      
    </div>
    </div>
	 
	    <div class="col-lg-2">
    <div class="form-group">
     
   <button type="submit" name="search"  class="btn btn-default btn-success mg24">Search</button>
    </div>
    </div>
  </form>
                         
                       </div>
                   </div>

                          </div>
                       
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
	
	
<script>
var x, i, j, selElmnt, a, b, c;
/*look for any elements with the class "custom-select":*/
x = document.getElementsByClassName("custom-select");
for (i = 0; i < x.length; i++) {
  selElmnt = x[i].getElementsByTagName("select")[0];
  /*for each element, create a new DIV that will act as the selected item:*/
  a = document.createElement("DIV");
  a.setAttribute("class", "select-selected");
  a.innerHTML = selElmnt.options[selElmnt.selectedIndex].innerHTML;
  x[i].appendChild(a);
  /*for each element, create a new DIV that will contain the option list:*/
  b = document.createElement("DIV");
  b.setAttribute("class", "select-items select-hide");
  for (j = 0; j < selElmnt.length; j++) {
    /*for each option in the original select element,
    create a new DIV that will act as an option item:*/
    c = document.createElement("DIV");
    c.innerHTML = selElmnt.options[j].innerHTML;
    c.addEventListener("click", function(e) {
        /*when an item is clicked, update the original select box,
        and the selected item:*/
        var y, i, k, s, h;
        s = this.parentNode.parentNode.getElementsByTagName("select")[0];
        h = this.parentNode.previousSibling;
        for (i = 0; i < s.length; i++) {
          if (s.options[i].innerHTML == this.innerHTML) {
            s.selectedIndex = i;
            h.innerHTML = this.innerHTML;
            y = this.parentNode.getElementsByClassName("same-as-selected");
            for (k = 0; k < y.length; k++) {
              y[k].removeAttribute("class");
            }
            this.setAttribute("class", "same-as-selected");
            break;
          }
        }
        h.click();
    });
    b.appendChild(c);
  }
  x[i].appendChild(b);
  a.addEventListener("click", function(e) {
      /*when the select box is clicked, close any other select boxes,
      and open/close the current select box:*/
      e.stopPropagation();
      closeAllSelect(this);
      this.nextSibling.classList.toggle("select-hide");
      this.classList.toggle("select-arrow-active");
    });
}
function closeAllSelect(elmnt) {
  /*a function that will close all select boxes in the document,
  except the current select box:*/
  var x, y, i, arrNo = [];
  x = document.getElementsByClassName("select-items");
  y = document.getElementsByClassName("select-selected");
  for (i = 0; i < y.length; i++) {
    if (elmnt == y[i]) {
      arrNo.push(i)
    } else {
      y[i].classList.remove("select-arrow-active");
    }
  }
  for (i = 0; i < x.length; i++) {
    if (arrNo.indexOf(i)) {
      x[i].classList.add("select-hide");
    }
  }
}
/*if the user clicks anywhere outside the select box,
then close all select boxes:*/
document.addEventListener("click", closeAllSelect);</script>



	<?php
include 'footer.php';?>