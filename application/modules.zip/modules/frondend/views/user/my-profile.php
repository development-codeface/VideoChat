<?php
include 'header.php' ;?>	
		<section class="cover-sec">
		<?php if($mydata['cover_photo']!=""){?>
			<img src="<?php echo base_url() .'uploads/cover_photo/'.$mydata['cover_photo'] ;?>" alt="">
		<?php }else{
			?>
			<img src="<?php echo base_url(); ?>assets/images/resources/cover-img.jpg" alt="">
		<?php }?>
			<a href="#" title="" id=""><i class="fa fa-camera"><input type="hidden"></i> Change Image</a>
		</section>


		<main>
			<div class="main-section">
				<div class="container">
					<div class="main-section-data">
						<div class="row">
							<div class="col-lg-3">
								<div class="main-left-sidebar">
									<div class="user_profile">
										<div class="user-pro-img">
										  <?php if($mydata['profile_pic']!=""){?>
											<img src="<?php echo base_url() .'uploads/cover_photo/'.$mydata['profile_pic'] ;?>" alt="">
											<?php }else{?>
											<img src="<?php echo base_url(); ?>assets/images/resources/user-pro-img.png" alt="">
											<?php }?>
										
										
											
											<a href="#" title=""><i class="fa fa-camera"></i></a>
											<ul class="flw-status">
												<li>
													<span> <?php  echo $mydata['nick_name'];?></span>
												
												</li>
												
											</ul>
										</div><!--user-pro-img end-->
										
										
									</div><!--user_profile end-->
									<div class="suggestions full-width">
										<div class="sd-title">
											<h3>People Viewed Profile</h3>
											
										</div><!--sd-title end-->
										<div class="suggestions-list">
										
										<?php if(!empty($profileViewer)){
											$i=1;
											foreach($profileViewer as $frq){?>
										
											<div class="suggestion-usd">
											
											  <?php if($frq->profile_pic!=""){?>
											<img src="<?php echo base_url() .'uploads/profile_pic/'.$frq->profile_pic ;?>" alt="">
											<?php }else{?>
											<img src="<?php echo base_url(); ?>assets/images/resources/s1.png" alt="">
											<?php }?>
											
											<div class="sgt-text">
													<h4><?php echo $frq->full_name;?></h4>
													
												</div>
												<span><i class="fa fa-video-camera" aria-hidden="true"></i></span>
											</div>
										<?php }}?>
											
											
											
											
											
										</div><!--suggestions-list end-->
									</div><!--suggestions end-->
								</div><!--main-left-sidebar end-->
							</div>
							<div class="col-lg-9">
								<div class="main-ws-sec">
									<div class="user-tab-sec">
										<h3><?php  echo $mydata['full_name'];?></h3>
										<div class="star-descp">
										
											
										</div><!--star-descp end-->
										<div class="tab-feed st2">
											<ul>
												<li data-tab="feed-dd" class="active">
													<a href="#" title="">
														<i class="fa fa-user" aria-hidden="true"></i>
														<span>Feed</span>
													</a>
												</li>
												<li data-tab="info-dd">
													<a href="#" title="">
													<i class="fa fa-pencil-square-o" aria-hidden="true"></i>
														<span>Info</span>
													</a>
												</li>
												<li data-tab="portfolio-dd" >
													<a href="#" title="">
														<i class="fa fa-camera" aria-hidden="true"></i>
														<span>Portfolio</span>
													</a>
												</li>
													<li data-tab="my-frd">
													<a href="#" title="">
														<i class="fa fa-users" aria-hidden="true"></i>
														<span>My Friend Request</span>
													</a>
												</li>
												<li data-tab="my-frd-list">
													<a href="#" title="">
														<i class="fa fa-address-card col-sdd" aria-hidden="true"></i>
														<span>My Friend list</span>
													</a>
												</li>
												<!--li data-tab="payment-dd">
													<a href="#" title="">
														<i class="fa fa-money" aria-hidden="true"></i>
														<span>Payment</span>
													</a>
												</li-->
											</ul>
										</div><!-- tab-feed end-->
									</div><!--user-tab-sec end-->
									
									<div class="product-feed-tab current" id="feed-dd">
										<div class="posts-section">
											<div class="post-bar">
				
												<div class="post_topbar">
													<div class="usy-dt">
														<img src="images/resources/s4.png" alt="">
														<div class="usy-name">
															<h3>Poonam.</h3>
															<span>
1 hr</span> &nbsp;<span><i class="fa fa-flag" aria-hidden="true"></i> India</span>
														</div>
													</div>
													
												</div>
												
												<div class="job_descp">
													<h3>Amazing Tomato Carving Arts</h3>
													
													
													<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam luctus hendrerit metus, ut ullamcorper quam finibus at. Etiam id magna sit amet... </p>
												
												</div>
			
												<div class="job-status-bar">
													<ul class="like-com">
														<li>
															<a href="#"><i class="la la-heart"></i> Like</a>
															<img src="images/liked-img.png" alt="">
													
														</li> 
													
													</ul>
												
												</div>
											</div>
										
										</div><!--posts-section end-->
									</div><!--product-feed-tab end-->
									<div class="product-feed-tab" id="info-dd">
									<div class="user-profile-ov st2">
									
											<h3><a href="#" title="" class="exp-bx-open">Basic Information </a><a href="#" title="" class="exp-bx-open"><i class="fa fa-pencil"></i></a></h3>
											<h4>Name : <i id="full_names"> <?php  echo $mydata['full_name'];?></i></h4>
											<h4>Nick Name : <i id="nick_names"> <?php  echo $mydata['nick_name'];?></i></h4>
											
											<h4>Gender : <i id="genders"> <?php if($mydata['gender']==1){?>Female<?php }else {?> Male <?php }?></i></h4>
											<h4>Date of birth : <i id="dobs"> <?php  echo $mydata['dob'];?></i></h4>
											<label for="pwd">private /  public:</label>
											<label class="switch swtlastm">
												<input type="checkbox" checked>
												<span class="slider round"></span>
											</label>
										</div><!--user-profile-ov end-->
										<div class="user-profile-ov">
											<h3><a href="#" title="" class="lct-box-open">Location</a> <a href="#" title="" class="lct-box-open"><i class="fa fa-pencil"></i></a></h3>
											<h4 id="country_ids"><?php  echo $mydata['country_id'];?></h4>
											<p id="addres"> <?php  echo $mydata['address'];?></p>
										</div><!--user-profile-ov end-->
										<div class="user-profile-ov">
											<h3><a href="#" title="" class="overview-open">Overview</a> <a href="#" title="" class="overview-open"><i class="fa fa-pencil"></i></a></h3>
											<p id="descriptions"><?php  echo $mydata['description'];?></p>
										</div><!--user-profile-ov end-->
										
										<div class="user-profile-ov">
											<h3><a href="#" title="" class="ed-box-open">Education</a> <a href="#" title="" class="ed-box-open"><i class="fa fa-pencil"></i></a> <a href="#" title=""><i class="fa fa-plus-square"></i></a></h3>
											<h4>Master of Computer Science</h4>
											<span>2015 - 2018</span>
											<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque tempor aliquam felis, nec condimentum ipsum commodo id. Vivamus sit amet augue nec urna efficitur tincidunt. Vivamus consectetur aliquam lectus commodo viverra. </p>
										</div><!--user-profile-ov end-->
									
										<div class="user-profile-ov">
											<h3><a href="#" title="" class="skills-open">Interest</a> <a href="#" title="" class="skills-open"><i class="fa fa-pencil"></i></a> <a href="#"><i class="fa fa-plus-square"></i></a></h3>
											<ul>
												<li><a href="#" title="">Boy</a></li>
												<li><a href="#" title="">Girl</a></li>
												<li><a href="#" title="">Other</a></li>
												
											</ul>
										</div><!--user-profile-ov end-->
									</div><!--product-feed-tab end-->
									
									<div class="product-feed-tab" id="portfolio-dd">
										<div class="portfolio-gallery-sec">
											<h3>Portfolio</h3>
										<div class="gallery_pf">
												<div class="row">
													<div class="col-lg-4 col-md-4 col-sm-4 col-6">
														<div class="gallery_pt">
															<img id="myImg" src="<?php echo base_url(); ?>assets/images/Events.jpg" alt="">
														<a href="#" title=""><img src="<?php echo base_url(); ?>assets/images/all-out.png" alt=""></a> 
														</div><!--gallery_pt end-->
													</div>
													<div class="col-lg-4 col-md-4 col-sm-4 col-6">
														<div class="gallery_pt">
															<img id="myImg" src="<?php echo base_url(); ?>assets/images/ev.jpg" alt="">
														<a href="#" title=""><img src="<?php echo base_url(); ?>assets/images/all-out.png" alt=""></a>
														</div><!--gallery_pt end-->
													</div>
													<div class="col-lg-4 col-md-4 col-sm-4 col-6">
														<div class="gallery_pt">
															<img id="myImg" src="<?php echo base_url(); ?>assets/images/eve.jpg" alt="">
														<a href="#" title=""><img src="<?php echo base_url(); ?>assets/images/all-out.png" alt=""></a>
														</div><!--gallery_pt end-->
													</div>
												
												</div>
												<div id="myModal" class="modal">
  <span class="close">×</span>
  <img class="modal-content" id="img01">
  <div id="caption"></div>
</div>
											</div>
										</div><!--portfolio-gallery-sec end-->
									</div><!--product-feed-tab end-->
									
									<div class="product-feed-tab" id="my-frd">
									<div class="acc-setting">
							  			<h3>My Friend Requests</h3>
							  			<div class="requests-list widt100">
										<?php if(!empty($friendsRequest)){
											$i=1;
											foreach($friendsRequest as $frq){?>
							  				<div class="request-details" id="<?php echo $frq->user_id;?>">
							  					<div class="noty-user-img">
													<?php if($frq->profile_pic!=""){?>
											<img src="<?php echo base_url() .'uploads/profile_pic/'.$frq->profile_pic ;?>" alt="">
											<?php }else{?>
											<img src="<?php echo base_url(); ?>assets/images/resources/r-img1.png" alt="">
											<?php }?>
							  					
							  					</div>
							  					<div class="request-info">
							  						<h3><?php echo $frq->full_name ;?></h3>
							  						
							  					</div>
							  					<div class="accept-feat">
							  						<ul>
							  							<li><button type="button" class="accept-req" onclick="friendAccept(<?php echo $frq->user_id;?>)">Accept</button></li>
							  							<li><button type="button" class="close-req"><i class="la la-close"></i></button></li>
							  						</ul>
							  					</div><!--accept-feat end-->
							  				</div><!--request-detailse end-->
										<?php }}?>
							  				
							  				
							  				
							  				
							  			</div><!--requests-list end-->
							  		</div>
									</div>
										<div class="product-feed-tab" id="my-frd-list">
										<div class="row">
										
										<?php if(!empty($friendList)){
											$i=1;
											foreach($friendList as $frq){?>
										<div class="col-lg-3 col-md-4 col-sm-6 col-12">
							<div class="company_profile_info">
								<div class="company-up-info">	
								<?php if( $frq->status==1){?>
								<i class="fa fa-circle msg-online" aria-hidden="true"> <span>Online</span></i><?php }else{?>
								<i class="fa fa-circle msg-off" aria-hidden="true"> <span>Offline</span></i><?php }?>
								<div class="clearfix"></div>
									<a href="<?php echo base_url() .'index.php/frondend/Profile/profileView/'.$frq->user_id;?>">
									 <?php if($frq->profile_pic!=""){?>
											<img src="<?php echo base_url() .'uploads/profile_pic/'.$frq->profile_pic ;?>" alt="">
											<?php }else{?>
											<img src="<?php echo base_url(); ?>assets/images/resources/pf-icon8.png" alt="">
											<?php }?>
									
									
									</a>
										<h3><a href="<?php echo base_url() .'index.php/frondend/Profile/profileView/'.$frq->user_id;?>"><?php echo $frq->full_name;?></a></h3>
									
									<ul>
										<li><a href="#" title="" class="follow"><i class="fa fa-video-camera" aria-hidden="true"></i></a></li>
										
										<li><a href="#" title="" class="hire-us"><i class="fa fa-comments-o" aria-hidden="true"></i></a></li>
									</ul>
								</div>
			
							</div><!--company_profile_info end-->
						</div>
										<?php }} ?>
						
						
						
								</div>
									</div>
									<!--div class="product-feed-tab" id="payment-dd">
										<div class="billing-method">
											<ul>
												<li>
													<h3>Add Billing Method</h3>
													<a href="#" title=""><i class="fa fa-plus-circle"></i></a>
												</li>
												<li>
													<h3>See Activity</h3>
													<a href="#" title="">View All</a>
												</li>
												<li>
													<h3>Total Money</h3>
													<span>$0.00</span>
												</li>
											</ul>
											<div class="lt-sec">
												<img src="images/lt-icon.png" alt="">
												<h4>All your transactions are saved here</h4>
												<a href="#" title="">Click Here</a>
											</div>
										</div>
										<div class="add-billing-method">
											<h3>Add Billing Method</h3>
											<h4><img src="images/dlr-icon.png" alt=""><span>With workwise payment protection , only pay for work delivered.</span></h4>
											<div class="payment_methods">
												<h4>Credit or Debit Cards</h4>
												<form>
													<div class="row">
														<div class="col-lg-12">
															<div class="cc-head">
																<h5>Card Number</h5>
																<ul>
																	<li><img src="images/cc-icon1.png" alt=""></li>
																	<li><img src="images/cc-icon2.png" alt=""></li>
																	<li><img src="images/cc-icon3.png" alt=""></li>
																	<li><img src="images/cc-icon4.png" alt=""></li>
																</ul>
															</div>
															<div class="inpt-field pd-moree">
																<input type="text" name="cc-number" placeholder="">
																<i class="fa fa-credit-card"></i>
															</div>
														</div>
														<div class="col-lg-6">
															<div class="cc-head">
																<h5>First Name</h5>
															</div>
															<div class="inpt-field">
																<input type="text" name="f-name" placeholder="">
															</div>
														</div>
														<div class="col-lg-6">
															<div class="cc-head">
																<h5>Last Name</h5>
															</div>
															<div class="inpt-field">
																<input type="text" name="l-name" placeholder="">
															</div>
														</div>
														<div class="col-lg-6">
															<div class="cc-head">
																<h5>Expiresons</h5>
															</div>
															<div class="rowwy">
																<div class="row">
																	<div class="col-lg-6 pd-left-none no-pd">
																		<div class="inpt-field">
																			<input type="text" name="f-name" placeholder="">
																		</div>
																	</div>
																	<div class="col-lg-6 pd-right-none no-pd">
																		<div class="inpt-field">
																			<input type="text" name="f-name" placeholder="">
																		</div>
																	</div>
																</div>
															</div>
														</div>
														<div class="col-lg-6">
															<div class="cc-head">
																<h5>Cvv (Security Code) <i class="fa fa-question-circle"></i></h5>
															</div>
															<div class="inpt-field">
																<input type="text" name="l-name" placeholder="">
															</div>
														</div>
														<div class="col-lg-12">
															<button type="submit">Continue</button>
														</div>
													</div>
												</form>
												<h4>Add Paypal Account</h4>
											</div>
										</div>
									</div-->
								</div><!--main-ws-sec end-->
							</div>
							
						</div>
					</div><!-- main-section-data end-->
				</div> 
			</div>
		</main>

	<footer>
			<div class="footy-sec mn no-margin">
				<div class="container">
					<ul>
						
						<li><a href="#" title="">Privacy Policy</a></li>
				
						<li><a href="#" title="">Terms & Conditions</a></li>
						<li><a href="#" title="">Cookies </a></li>
						<li><a href="#" title="">Contact</a></li>
					</ul>
					<p>Copyright 2018 . All rights reserved</p>
				
				</div>
			</div>
		</footer>

		<div class="overview-box" id="overview-box">
			<div class="overview-edit">
				<h3>Overview</h3>
				<span>5000 character left</span>
				<form method="POST">
					<textarea id="description"><?php echo $mydata['description'];?></textarea>
					<button type="button" class="save" id="descriptionsave">Save</button>
					<button type="button" class="cancel">Cancel</button>
				</form>
				<a href="#" title="" class="close-box"><i class="la la-close"></i></a>
			</div><!--overview-edit end-->
		</div><!--overview-box end-->

<div class="overview-box" id="about-box">
			<div class="overview-edit">
				<h3>About</h3>
				<form>
					<input type="text" name="subject" placeholder="Name">
					<input type="text" name="subject" placeholder="Nick Name">
					
					<button type="submit" class="save">Save</button>
					<button type="submit" class="save-add">Save & Add More</button>
					<button type="submit" class="cancel">Cancel</button>
				</form>
				<a href="#" title="" class="close-box"><i class="la la-close"></i></a>
			</div><!--overview-edit end-->
		</div><!--overview-box end-->
	<div class="overview-box" id="experience-box">
			<div class="overview-edit">
				<h3>Basic Information</h3>
				<form method="POST" ACTION="">
					<input type="text" name="full_name" id="full_name" placeholder="Name" value="<?php  echo $mydata['full_name'];?>">
					<input type="text" name="nick_name" id="nick_name" placeholder="Nick Name" value="<?php  echo $mydata['nick_name'];?>">
					<input type="date" name="dob"  id="dob" placeholder="Date of birth" value="<?php  echo $mydata['dob'];?>">
					<div class="form-group">
					
		  <label class="checkbox-inline"><b>Gender </b> :</label>
		  <?php   $f="";$m="";if($mydata['gender']==1){ $m="checked";}else{ $f="checked";}?>
		  <label class="checkbox-inline"><input type="radio" name="gender" id="gender" <?php echo $f;?> style=" width: 15px;
    height: 15px;" value="1" >&nbsp;Female </label>
<label class="checkbox-inline"><input type="radio" name="gender"  id="gender" <?php echo $m;?> style="width: 15px;
    height: 15px;"  value="2">&nbsp;Male </label>
</div>
<div class="form-group">
<label for="pwd">private /  public:</label>
<label class="switch swtlastm">
  <input type="checkbox" name="visibility"  id="visibility">
  <span class="slider round"></span>
</label>
</div>
					<button type="button" id="basicinfo" class="save" >Save</button>
				
					<button type="button" class="cancel">Cancel</button>
				</form>
				<a href="#" title="" class="close-box"><i class="la la-close"></i></a>
			</div><!--overview-edit end-->
		</div><!--overview-box end-->

		<div class="overview-box" id="education-box">
			<div class="overview-edit">
				<h3>Education</h3>
				<form>
					<input type="text" name="school" placeholder="School / University">
					<div class="datepicky">
						<div class="row">
							<div class="col-lg-6 no-left-pd">
								<div class="datefm">
									<input type="text" name="from" placeholder="From" class="datepicker">	
									<i class="fa fa-calendar"></i>
								</div>
							</div>
							<div class="col-lg-6 no-righ-pd">
								<div class="datefm">
									<input type="text" name="to" placeholder="To" class="datepicker">
									<i class="fa fa-calendar"></i>
								</div>
							</div>
						</div>
					</div>
					<input type="text" name="degree" placeholder="Degree">
					<textarea placeholder="Description"></textarea>
					<button type="submit" class="save">Save</button>
					<button type="submit" class="save-add">Save & Add More</button>
					<button type="submit" class="cancel">Cancel</button>
				</form>
				<a href="#" title="" class="close-box"><i class="la la-close"></i></a>
			</div><!--overview-edit end-->
		</div><!--overview-box end-->

		<div class="overview-box" id="location-box">
			<div class="overview-edit">
				<h3>Location</h3>
				<form>
					<div class="datefm">
						<select name="country_id" id="country_id">
							<option>Country</option>
							<option value="India">India</option>
							<option value="pakistan">Pakistan</option>
							<option value="England">England</option>
							<option value="China">China</option>
							<option value="UAE">UAE</option>
							<option value="United Sates">United Sates</option>
							
						</select>
						<i class="fa fa-globe"></i>
					</div>
					<div class="datefm">
						<input type="text" name="address"  id="address" placeholder="locations" >	
						<i class="fa fa-map-marker"></i>
					</div>
					<button type="button" class="save" id="locationSave" >Save</button>
					<button type="button" class="cancel">Cancel</button>
				</form>
				<a href="#" title="" class="close-box"><i class="la la-close"></i></a>
			</div><!--overview-edit end-->
		</div><!--overview-box end-->

		<div class="overview-box" id="skills-box">
			<div class="overview-edit">
				<h3>Interest</h3>
				<ul>
					<li><a href="#" title="" class="skl-name">HTML</a><a href="#" title="" class="close-skl"><i class="la la-close"></i></a></li>
					<li><a href="#" title="" class="skl-name">php</a><a href="#" title="" class="close-skl"><i class="la la-close"></i></a></li>
					<li><a href="#" title="" class="skl-name">css</a><a href="#" title="" class="close-skl"><i class="la la-close"></i></a></li>
				</ul>
				<form>
					<input type="text" name="skills" placeholder="Skills">
					<button type="submit" class="save">Save</button>
					<button type="submit" class="save-add">Save & Add More</button>
					<button type="submit" class="cancel">Cancel</button>
				</form>
				<a href="#" title="" class="close-box"><i class="la la-close"></i></a>
			</div><!--overview-edit end-->
		</div><!--overview-box end-->

		<div class="overview-box" id="create-portfolio">
			<div class="overview-edit">
				<h3>Create Portfolio</h3>
				<form>
					<input type="text" name="pf-name" placeholder="Portfolio Name">
					<div class="file-submit">
						<input type="file" name="file">
					</div>
					
					<input type="text" name="website-url" placeholder="htp://www.example.com">
					<button type="submit" class="save">Save</button>
					<button type="submit" class="cancel">Cancel</button>
				</form>
				<a href="#" title="" class="close-box"><i class="la la-close"></i></a>
			</div><!--overview-edit end-->
		</div><!--overview-box end-->

	</div><!--theme-layout end-->

<script>
  var site_url='<?php  echo base_url();?>index.php/frondend/';
  </script>

<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/jquery.min.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/popper.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/bootstrap.min.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/flatpickr.min.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/lib/slick/slick.min.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/script.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/custom.js"></script>
</body>

</html>